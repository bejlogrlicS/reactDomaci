import "./Home.css"
function Home(){
 return(
   <div className="center">
      <div className="pocetna">
        <h2 className="text">News on all your favourite teams</h2>
        <img src="./images/logo.png" alt="slika"className="photo"></img>
    </div>
    
   </div>
    
 )
}

export default Home;
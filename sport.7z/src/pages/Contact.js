import Form from "../components/Form";

function Contact(){
    return (
        <div>
            <h1 style={{"text-align":"center","margin-top":"50px"}}>Contact us if you have any questions</h1>
            <Form/>
        </div>
  
    )
}
export default Contact;